﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _24oras2008
{
    public partial class Form1 : Form
    {
        static int pid = 1;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            StreamReader sr=new StreamReader(new FileStream("../../../feladat1/in.txt",FileMode.Open));
            int n = Convert.ToInt32(sr.ReadLine()),i=0;
            string []s;
            List<Szobeszed> plety=new List<Szobeszed>();
            Falu village = new Falu(n);
            while (!sr.EndOfStream)
            {
                i++;
                s = sr.ReadLine().Split(' ');
                plety.Add(new Szobeszed(Convert.ToInt32(s[0]), Convert.ToInt32(s[1])));
            }
            sr.Close();
            foreach(var p in plety)
            {
                village.process(p);
            }
            origin(village);
            unknown(village);
            pfeszek(village);
            lustak(village);
        }
        public void origin(Falu f)
        {
            string s = "";
            foreach(var e in f.ember)
            {
                if (e.kapta == -1&&e.tudja)
                {
                    s += e.id+", ";
                }
            }
            textBox1.Text = s;
        }

        public void unknown(Falu f)
        {
            string s = "";
            foreach(var e in f.ember)
            {
                if (!e.tudja)
                    s += e.id + ", ";
            }
            textBox2.Text = s;
        }

        public void pfeszek(Falu f)
        {
            int max=0;
            string s = "";
            for(int i = 1; i < f.ember.Count; i++)
            {
                if (f.ember[i].mondta.Count> f.ember[max].mondta.Count)
                {
                    max = i;
                }
            }
            for (int i = 1; i < f.ember.Count; i++)
            {
                if (f.ember[i].mondta.Count == f.ember[max].mondta.Count)
                {
                    s += f.ember[i].id + ", ";
                }
            }
            textBox3.Text = s;
        }

        public void lustak(Falu f)
        {
            string s="";
            foreach(var e in f.ember)
            {
                if (e.lusta()&&e.tudja)
                {
                    s += e.id + ", ";
               
                }
            }
            textBox4.Text = s;
        }

        public class Szobeszed
        {
            public int from { get; set; }
            public int to { get; set; }
            public Szobeszed(int from, int to)
            {
                this.from = from;
                this.to = to;
            }
        }
        public class Lakos
        {
            public HashSet<int> mondta;
            public int id { get; set; }
            public int kapta { get; set; }

            public bool tudja { get; set; }
            public bool lusta()
            {
                if (mondta.Count == 0)
                {
                    return true;
                }
                return false;
            }
            public Lakos(int id)
            {
                this.mondta = new HashSet<int>();
                this.id = id;
                this.kapta = -1;
                this.tudja = false;
            }
            public void mondja(int i)
            {
                mondta.Add(i);
            }
            public void megtud(int i)
            {
                this.kapta =i;
                tudja = true;
            }
            public void megtud()
            {
                tudja = true;
            }
        }
        public class Falu{
            public List<Lakos> ember;

            public Falu(int n)
            {
                ember = new List<Lakos>();
                for(int i = 1; i <= n; i++)
                {
                    ember.Add(new Lakos(i));
                }
            }
            public void process(Szobeszed besz)
            {
                ember[besz.from-1].megtud();
                ember[besz.from-1].mondja(besz.to);
                ember[besz.to-1].megtud(besz.from);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (StreamReader sr = new StreamReader(new FileStream("../../../feladat2/in.txt", FileMode.Open)))
            {
                string[] s;
                s = sr.ReadLine().Split(' ');
                Verseny komp = new Verseny(s.Length);
                for (int j = 0; j < s.Length; j++)
                {
                    komp.diak[j].kedvelt.Add(Convert.ToInt32(s[j]));
                }
                while (!sr.EndOfStream)
                {
                    s = sr.ReadLine().Split(' ');
                    for (int j = 0; j < s.Length; j++)
                    {
                        komp.diak[j].kedvelt.Add(Convert.ToInt32(s[j]));
                    }
                }
                csapatvalasztas(komp);
            }
        }

        public void csapatvalasztas(Verseny ver)
        {
            int i;
            List<Csapat> team = new List<Csapat>();
            for (i = 0; i+2 < ver.diak.Count; i++)
                for (int j = i + 1; j+1 < ver.diak.Count && j != i; j++)
                    for (int k = j + 1; k < ver.diak.Count && k != i && k != j; k++)
                        team.Add(new Csapat(ver.diak[i], ver.diak[j], ver.diak[k]));
            team.Sort((cs1, cs2) => cs1.boldog.CompareTo(cs2.boldog));
            for (i = team.Count - 1; i >= 0; i--)
            {
                if (team[i].letezhet())
                {
                    listBox1.Items.Add(team[i].idk());
                    team[i].csapatAlakult();
                }
            }
            string s = "";
            foreach(var d in ver.diak)
            {
                if (!d.csapattag)
                {
                    s += d.id + ", ";
                }
            }
            listBox2.Items.Add(s);
        }

        public class Versenyzo
        {
            public bool csapattag=false;
            public int id { get; set; }
            public List<int> kedvelt = new List<int>();
            public Versenyzo(int id)
            {
                this.id=id;
            }
        }

        public class Verseny
        {
            public List<Versenyzo> diak=new List<Versenyzo>();
            public Verseny(int n)
            {
                for (int i = 0; i < n; i++)
                    diak.Add(new Versenyzo(i + 1));
            }
        }

        public class Csapat
        {
            public Versenyzo[] tag;
            public List<int> id ;
            public int boldog=0;
            
            public Csapat()
            {
                tag = new Versenyzo[3];
            }
            public Csapat(Versenyzo a, Versenyzo b, Versenyzo c)
            {
                tag = new Versenyzo[3];
                tag[0] = a;
                tag[1] = b;
                tag[2] = c;
                id = new List<int>();
                id.Add(a.id);
                id.Add(b.id);
                id.Add(c.id);
                calcBoldog();
            }
            public bool letezhet()
            {
                int a = 0;
                for (int i = 0; i < tag.Length; i++)
                    if (!tag[i].csapattag)
                        a++;
                return a == 3;
            }
            public void calcBoldog()
            {
                for(int i = 0; i < tag.Length; i++)
                {
                    for(int j = 0; j < tag.Length; j++)
                    {
                        if (tag[i].kedvelt.Contains(tag[j].id)&&j!=i)
                            boldog++;
                    }
                }
            }
            public string idk()
            {
                return tag[0].id + ", " + tag[1].id + ", " + tag[2].id;
            }

            public void csapatAlakult()
            {
                for(int i=0;i<tag.Length; i++)
                {
                    tag[i].csapattag = true;
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            string osztando;
            string oszto;
            using (StreamReader sr = new StreamReader(new FileStream("../../../feladat3/in.txt", FileMode.Open)))
            {
                osztando = sr.ReadLine();
                oszto = sr.ReadLine();
            }
            BigInteger andon=BigInteger.Parse(osztando);
            BigInteger ton= BigInteger.Parse(oszto);
            BigInteger marad;
            BigInteger ered=BigInteger.DivRem(andon, ton,out marad);
            textBox5.Text = ered.ToString();
            textBox6.Text = marad.ToString();
        }

        //public int factorial(int n)
        //{
        //    if (n == 1)
        //        return 1;
        //    else
        //        return n*factorial(n-1);
        //}
    }
}
